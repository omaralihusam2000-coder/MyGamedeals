/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface UserWishlistItem {
  gameId: string;
  title: string;
  thumb: string;
  addedAt: number;
  targetPrice?: number;
  currentBestPrice?: number;
}

export interface AppUser {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
}
