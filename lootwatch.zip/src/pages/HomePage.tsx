/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { Deal, cheapSharkService, Store } from '../services/cheapShark';
import { motion } from 'motion/react';
import { TrendingUp, Filter, ArrowRight, Gift, Clock, Tag, Award, Calendar, Star, TrendingDown } from 'lucide-react';
import { Link } from 'react-router-dom';

export function DealCard({ deal, stores }: { deal: Deal; stores: Store[] }) {
  const store = stores.find(s => s.storeID === deal.storeID);
  const savings = Math.round(parseFloat(deal.savings));
  const isFree = parseFloat(deal.salePrice) === 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      whileHover={{ y: -5 }}
      className={`group relative bg-[#111] border rounded-xl overflow-hidden transition-all ${
        isFree ? 'border-yellow-500/50 shadow-[0_0_20px_rgba(234,179,8,0.1)]' : 'border-white/5 hover:border-orange-500/40'
      }`}
    >
      <Link to={`/game/${deal.gameID}`}>
        <div className="relative aspect-[16/9] overflow-hidden">
          <img
            src={deal.thumb}
            alt={deal.title}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
          
          <div className="absolute top-2 left-2 flex gap-2">
            {isFree ? (
              <span className="bg-yellow-500 text-black text-[10px] font-black px-2 py-1 rounded skew-x-[-10deg] flex items-center gap-1">
                <Gift size={10} />
                FREE
              </span>
            ) : savings > 0 && (
              <span className="bg-orange-600 text-white text-[10px] font-black px-2 py-1 rounded skew-x-[-10deg]">
                -{savings}%
              </span>
            )}
            {deal.steamAppID && (
              <span className="bg-[#1b2838] text-white text-[10px] font-bold px-2 py-1 rounded">
                STEAM
              </span>
            )}
          </div>

          <div className="absolute bottom-2 left-2 right-2 flex justify-between items-end">
             <div className="flex flex-col">
                <span className="text-white font-bold text-sm line-clamp-1 group-hover:text-orange-500 transition-colors">
                  {deal.title}
                </span>
                <div className="flex items-center gap-2">
                   {store && store.images.icon && (
                    <img 
                      src={`https://www.cheapshark.com${store.images.icon}`} 
                      alt={store.storeName} 
                      className="w-4 h-4 rounded"
                      referrerPolicy="no-referrer"
                    />
                  )}
                   <span className="text-gray-400 text-[10px] uppercase tracking-wider">{store?.storeName}</span>
                </div>
             </div>
          </div>
        </div>
        
        <div className="p-4 flex items-center justify-between">
          <div className="flex flex-col">
            <span className="text-gray-500 text-[10px] line-through">${deal.normalPrice}</span>
            <span className="text-white text-xl font-black tracking-tight">${deal.salePrice}</span>
          </div>
          
          <div className="flex items-center gap-1 text-[10px] font-bold uppercase py-1 px-3 bg-white/5 rounded-full text-gray-400 group-hover:bg-orange-600 group-hover:text-white transition-all">
            VIEW DEAL
            <ArrowRight size={10} />
          </div>
        </div>
      </Link>
    </motion.div>
  );
}

function DealCardSkeleton() {
  return (
    <div className="bg-[#111] border border-white/5 rounded-xl overflow-hidden">
      <div className="aspect-[16/9] bg-white/5 animate-pulse" />
      <div className="p-4 space-y-3">
        <div className="flex justify-between items-center">
          <div className="space-y-2">
            <div className="h-2 w-16 bg-white/5 rounded animate-pulse" />
            <div className="h-5 w-24 bg-white/5 rounded animate-pulse" />
          </div>
          <div className="h-8 w-20 bg-white/5 rounded-full animate-pulse" />
        </div>
      </div>
    </div>
  );
}

export default function HomePage() {
  const [deals, setDeals] = useState<Deal[]>([]);
  const [stores, setStores] = useState<Store[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [sortBy, setBy] = useState('Recent');
  const [page, setPage] = useState(0);

  const sortMap: Record<string, string> = {
    'Recent': 'Recent',
    'Upcoming': 'Release',
    'Savings': 'Savings',
    'Price': 'Price',
    'Metacritic': 'Metacritic',
    'Reviews': 'Reviews',
    'Rating': 'Deal Rating'
  };

  const loadData = async (reset = false) => {
    const targetPage = reset ? 0 : page + 1;
    if (reset) {
      setLoading(true);
    } else {
      setLoadingMore(true);
    }

    try {
      const params: any = {
        pageSize: '40',
        pageNumber: targetPage.toString(),
        sortBy: sortMap[sortBy] || 'Recent',
        desc: (sortBy === 'Upcoming' || sortBy === 'Recent') ? '1' : '0'
      };

      // CheapShark sorts Price and Savings specifically, but 'Free' is a client filter for simplicity
      // since the API doesn't have a 'Free' sort, but often Free games have 100% savings.
      
      const dealsData = await cheapSharkService.getDeals(params);
      
      if (reset) {
        setDeals(dealsData);
        setPage(0);
      } else {
        setDeals(prev => [...prev, ...dealsData]);
        setPage(targetPage);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  };

  useEffect(() => {
    if (stores.length === 0) {
      cheapSharkService.getStores().then(setStores);
    }
  }, []);

  useEffect(() => {
    loadData(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [sortBy]);

  const loadMore = () => loadData(false);

  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <section className="relative h-[40vh] min-h-[300px] rounded-3xl overflow-hidden border border-white/10 group">
        <img 
          src="https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=2070" 
          alt="Gaming backdrop" 
          className="absolute inset-0 w-full h-full object-cover brightness-50 grayscale group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/40 to-transparent" />
        <div className="absolute inset-0 p-8 flex flex-col justify-center max-w-2xl">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-4"
          >
            <span className="inline-block px-3 py-1 bg-orange-600 text-white text-[10px] font-black uppercase tracking-[3px]">
              LIVE DEALS
            </span>
            <h1 className="text-5xl md:text-6xl font-black tracking-tighter leading-none">
              STOP PAYING <br/> <span className="text-orange-500">FULL PRICE.</span>
            </h1>
            <p className="text-gray-400 text-lg max-w-md">
              The ultimate video game deal tracker. Compare prices across all major platforms and never miss a sale.
            </p>
            <div className="flex gap-4 pt-4">
              <button 
                onClick={() => document.getElementById('deals-section')?.scrollIntoView({ behavior: 'smooth' })}
                className="bg-white text-black px-8 py-3 rounded-xl font-black text-sm uppercase transition-all hover:scale-105 hover:bg-orange-500 hover:text-white shadow-xl shadow-black/20"
              >
                VIEW DEALS
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Deals Grid */}
      <section id="deals-section" className="space-y-8 scroll-mt-24">
        <div className="flex flex-col sm:row sm:items-center justify-between gap-4 border-b border-white/5 pb-6">
          <div className="flex items-center gap-3">
            <div className="w-2 h-8 bg-orange-500" />
            <h2 className="text-3xl font-black tracking-tighter uppercase">Fresh Loot</h2>
          </div>
          
          <div className="flex items-center gap-2 overflow-x-auto pb-2 sm:pb-0 scrollbar-hide">
            {[
              { id: 'Recent', icon: Clock },
              { id: 'Upcoming', icon: Calendar },
              { id: 'Savings', icon: TrendingDown },
              { id: 'Price', icon: Tag },
              { id: 'Metacritic', icon: Award },
              { id: 'Rating', icon: Star },
              { id: 'Free', icon: Gift }
            ].map(f => (
              <button
                key={f.id}
                onClick={() => setBy(f.id)}
                className={`flex items-center gap-2 shrink-0 px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest transition-all border ${
                  sortBy === f.id 
                    ? 'bg-orange-500 border-orange-500 text-white shadow-[0_0_15px_rgba(249,115,22,0.3)]' 
                    : 'border-white/10 text-gray-500 hover:text-white hover:border-white/30'
                }`}
              >
                <f.icon size={12} />
                {f.id}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {loading ? (
            Array.from({ length: 12 }).map((_, i) => (
              <DealCardSkeleton key={i} />
            ))
          ) : (
            deals
              .filter(d => {
                const isFree = parseFloat(d.salePrice) === 0;
                const matchesFreeFilter = sortBy === 'Free' ? isFree : true;
                const hasSavings = parseFloat(d.savings) > 0 || isFree;
                return matchesFreeFilter && hasSavings;
              })
              .map(deal => (
                <DealCard key={deal.dealID} deal={deal} stores={stores} />
              ))
          )}
        </div>
        
        <div className="flex justify-center pt-12">
           <button 
            disabled={loadingMore}
            onClick={loadMore}
            className="flex items-center gap-2 px-8 py-4 border border-white/10 rounded-xl text-sm font-black uppercase hover:bg-white hover:text-black transition-all disabled:opacity-50 disabled:cursor-wait"
           >
              {loadingMore ? 'Scanning Market...' : 'Load More Loot'}
              {!loadingMore && <ArrowRight size={16} />}
           </button>
        </div>
      </section>
    </div>
  );
}
