/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { cheapSharkService, GameLookup, Store } from '../services/cheapShark';
import { User } from 'firebase/auth';
import { db } from '../lib/firebase';
import { doc, setDoc, deleteDoc, onSnapshot } from 'firebase/firestore';
import { Heart, ExternalLink, ShieldCheck, Tag, Info, AlertCircle, TrendingDown, Clock, Award, Share2, Check, BarChart as ChartIcon } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
  ReferenceLine
} from 'recharts';

export default function GameDetailsPage({ user }: { user: User | null }) {
  const { id } = useParams<{ id: string }>();
  const [game, setGame] = useState<GameLookup | null>(null);
  const [stores, setStores] = useState<Store[]>([]);
  const [loading, setLoading] = useState(true);
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [wishlistLoading, setWishlistLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  useEffect(() => {
    async function loadData() {
      if (!id) return;
      setLoading(true);
      try {
        const [gameData, storesData] = await Promise.all([
          cheapSharkService.getGameDeals(id),
          cheapSharkService.getStores()
        ]);
        setGame(gameData);
        setStores(storesData);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, [id]);

  useEffect(() => {
    if (!user || !id) {
      setIsWishlisted(false);
      return;
    }
    const wishlistDoc = doc(db, 'users', user.uid, 'wishlist', id);
    const unsubscribe = onSnapshot(wishlistDoc, (docSnap) => {
      setIsWishlisted(docSnap.exists());
    });
    return () => unsubscribe();
  }, [user, id]);

  const toggleWishlist = async () => {
    if (!user || !id || !game) return;
    setWishlistLoading(true);
    try {
      const wishlistDoc = doc(db, 'users', user.uid, 'wishlist', id);
      if (isWishlisted) {
        await deleteDoc(wishlistDoc);
      } else {
        const cheapestDeal = game.deals.reduce((prev, curr) => 
          parseFloat(curr.price) < parseFloat(prev.price) ? curr : prev
        );
        
        await setDoc(wishlistDoc, {
          gameId: id,
          title: game.info.title,
          thumb: game.info.thumb,
          addedAt: Date.now(),
          currentBestPrice: parseFloat(cheapestDeal.price),
          lastNotifiedPrice: parseFloat(cheapestDeal.price)
        });
      }
    } catch (e) {
      console.error(e);
    } finally {
      setWishlistLoading(false);
    }
  };

  if (loading) {
     return (
        <div className="py-20 flex justify-center">
          <div className="w-12 h-12 border-4 border-orange-500 border-t-transparent rounded-full animate-spin" />
        </div>
     );
  }

  if (!game) {
    return (
      <div className="text-center py-20 bg-red-500/10 rounded-3xl border border-red-500/20">
         <AlertCircle className="mx-auto text-red-500 mb-4" size={48} />
         <h2 className="text-2xl font-black uppercase italic">Critical System Failure: Game Not Found</h2>
         <Link to="/search" className="inline-block mt-4 text-orange-500 font-bold hover:underline">RETRY SCAN</Link>
      </div>
    );
  }

  const cheapestDeal = game.deals.reduce((prev, curr) => 
    parseFloat(curr.price) < parseFloat(prev.price) ? curr : prev
  );

  const isHistoricalLow = parseFloat(cheapestDeal.price) <= parseFloat(game.cheapestPriceEver.price);

  const chartData = game.deals.map(d => ({
    name: stores.find(s => s.storeID === d.storeID)?.storeName || 'Store',
    price: parseFloat(d.price),
    dealID: d.dealID
  })).sort((a, b) => a.price - b.price);

  return (
    <div className="space-y-12">
      {/* Header section */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-12 bg-white/[0.02] p-8 md:p-12 rounded-[2.5rem] border border-white/5 relative overflow-hidden">
         <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/10 blur-[100px] rounded-full sm:block hidden" />
         
         <div className="lg:col-span-1 space-y-6">
            <div className="aspect-[4/3] rounded-3xl overflow-hidden border border-white/10 shadow-2xl relative group">
               <img 
                 src={game.info.thumb} 
                 alt={game.info.title} 
                 className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" 
                 referrerPolicy="no-referrer"
               />
               <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
               <div className="absolute bottom-4 left-4 group-hover:bottom-6 transition-all flex flex-col gap-2">
                  <span className="bg-orange-600 text-white text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest bg-orange-500 shadow-[0_0_20px_rgba(249,115,22,0.4)]">
                     Verified Deal
                  </span>
                  {isHistoricalLow && (
                    <motion.div 
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="bg-yellow-500 text-black text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest flex items-center gap-1 shadow-[0_0_20px_rgba(234,179,8,0.4)]"
                    >
                       <Award size={12} />
                       Historical Low
                    </motion.div>
                  )}
               </div>
            </div>
            {user ? (
               <div className="flex gap-4">
                 <button 
                  onClick={toggleWishlist}
                  disabled={wishlistLoading}
                  className={`flex-1 flex items-center justify-center gap-3 py-4 rounded-2xl font-black uppercase tracking-widest transition-all ${
                    isWishlisted 
                      ? 'bg-red-500/10 text-red-500 border border-red-500/20 hover:bg-black hover:text-white hover:border-white/20' 
                      : 'bg-white text-black hover:bg-orange-500 hover:text-white shadow-xl hover:shadow-orange-500/20 transform hover:-translate-y-1'
                  }`}
                 >
                   <Heart size={20} fill={isWishlisted ? "currentColor" : "none"} className={wishlistLoading ? 'animate-pulse' : ''} />
                   {wishlistLoading ? 'Processing...' : isWishlisted ? 'IN WISHLIST' : 'TRACK THIS'}
                 </button>
                 <button 
                  onClick={handleShare}
                  className="px-6 py-4 rounded-2xl border border-white/10 hover:border-orange-500/40 hover:bg-orange-500/5 transition-all text-gray-400 hover:text-orange-500"
                  title="Share Game"
                 >
                   {copied ? <Check size={20} /> : <Share2 size={20} />}
                 </button>
               </div>
            ) : (
               <div className="bg-white/5 border border-dashed border-white/10 p-6 rounded-2xl text-center space-y-4">
                  <p className="text-sm font-bold text-gray-500 uppercase tracking-widest">Sign in to track price alerts</p>
                  <Link to="/" className="inline-block text-orange-500 font-black hover:underline">JOIN THE TRACKERS</Link>
               </div>
            )}
         </div>

         <div className="lg:col-span-2 space-y-8">
            <div className="space-y-4">
               <h1 className="text-5xl md:text-6xl font-black tracking-tighter leading-tight italic uppercase">
                 {game.info.title}
               </h1>
               <div className="flex flex-wrap gap-4 items-center">
                  <div className="flex items-center gap-2 px-4 py-2 bg-orange-500/10 border border-orange-500/20 rounded-full">
                     <TrendingDown size={16} className="text-orange-500" />
                     <span className="text-orange-500 font-bold">Best: ${cheapestDeal.price}</span>
                  </div>
                  <div className="flex items-center gap-2 px-4 py-2 bg-white/5 border border-white/10 rounded-full">
                     <Award size={16} className="text-yellow-500" />
                     <span className="text-yellow-500 font-bold uppercase text-xs tracking-wider">All-Time Low: ${game.cheapestPriceEver.price}</span>
                  </div>
                  <div className="flex items-center gap-2 px-4 py-2 bg-white/5 border border-white/10 rounded-full">
                     <Clock size={16} className="text-gray-400" />
                     <span className="text-gray-400 font-bold uppercase text-xs tracking-wider">Live Updates Enabled</span>
                  </div>
               </div>
            </div>

            <div className="space-y-6 pt-6">
                <div className="flex items-center gap-3">
                   <ChartIcon className="text-orange-500" size={24} />
                   <h2 className="text-2xl font-black tracking-tighter uppercase italic">Price Analysis</h2>
                </div>
                
                <div className="bg-white/[0.02] border border-white/5 p-6 rounded-3xl h-[300px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={chartData}
                      margin={{ top: 20, right: 30, left: 0, bottom: 50 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#222" vertical={false} />
                      <XAxis 
                        dataKey="name" 
                        stroke="#666" 
                        fontSize={10} 
                        tickLine={false} 
                        axisLine={false}
                        angle={-45}
                        textAnchor="end"
                        interval={0}
                      />
                      <YAxis 
                        stroke="#666" 
                        fontSize={10} 
                        tickLine={false} 
                        axisLine={false}
                        tickFormatter={(value) => `$${value}`}
                      />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: '#111', 
                          border: '1px solid rgba(255,255,255,0.1)',
                          borderRadius: '12px',
                          color: '#fff'
                        }}
                        itemStyle={{ color: '#f97316' }}
                      />
                      <ReferenceLine 
                        y={parseFloat(game.cheapestPriceEver.price)} 
                        stroke="#eab308" 
                        strokeDasharray="3 3" 
                        label={{ 
                          value: 'Lowest Ever', 
                          position: 'top', 
                          fill: '#eab308', 
                          fontSize: 10,
                          fontWeight: 'bold'
                        }} 
                      />
                      <Bar 
                        dataKey="price" 
                        radius={[4, 4, 0, 0]}
                        name="Store Price"
                      >
                        {chartData.map((entry, index) => (
                          <Cell 
                            key={`cell-${index}`} 
                            fill={entry.dealID === cheapestDeal.dealID ? '#f97316' : '#333'} 
                          />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
            </div>

            <div className="space-y-6 pt-6">
                <div className="flex items-center gap-3">
                   <Tag className="text-orange-500" size={24} />
                   <h2 className="text-2xl font-black tracking-tighter uppercase italic">Market Overview</h2>
                </div>
                
                <div className="grid gap-4">
                   {game.deals.map((deal) => {
                      const store = stores.find(s => s.storeID === deal.storeID);
                      const isBestPrice = deal.dealID === cheapestDeal.dealID;
                      
                      return (
                        <div 
                          key={deal.dealID}
                          className={`group flex items-center justify-between p-6 rounded-3xl transition-all border ${
                            isBestPrice 
                              ? 'bg-orange-500/5 border-orange-500/40' 
                              : 'bg-white/[0.02] border-white/5 hover:border-white/20'
                          }`}
                        >
                           <div className="flex items-center gap-4">
                              <div className="w-12 h-12 bg-white/5 rounded-xl flex items-center justify-center p-2 group-hover:scale-110 transition-transform">
                                {store?.images.logo && (
                                  <img 
                                    src={`https://www.cheapshark.com${store.images.logo}`} 
                                    alt={store.storeName} 
                                    className="max-w-full max-h-full object-contain filter grayscale group-hover:grayscale-0 transition-all"
                                    referrerPolicy="no-referrer"
                                  />
                                )}
                              </div>
                              <div>
                                 <h4 className="font-bold text-lg">{store?.storeName || 'Unknown Store'}</h4>
                                 <span className="text-[10px] font-black uppercase text-gray-500 tracking-widest">
                                    Retail: ${deal.retailPrice}
                                 </span>
                              </div>
                           </div>

                           <div className="flex items-center gap-6">
                              <div className="text-right">
                                 <div className="text-2xl font-black italic tracking-tighter text-white">
                                    ${deal.price}
                                 </div>
                                 {parseFloat(deal.savings) > 0 && (
                                   <span className="text-[10px] font-black text-orange-500 uppercase">
                                     SAVE {Math.round(parseFloat(deal.savings))}%
                                   </span>
                                 )}
                              </div>
                              <a 
                                href={`https://www.cheapshark.com/redirect?dealID=${deal.dealID}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className={`p-4 rounded-2xl transition-all ${
                                  isBestPrice 
                                    ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/20' 
                                    : 'bg-white/10 text-white hover:bg-white/20'
                                }`}
                              >
                                 <ExternalLink size={20} />
                              </a>
                           </div>
                        </div>
                      );
                   })}
                </div>
            </div>
         </div>
      </section>

      {/* Security/Trust Badges */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
         {[
           { icon: ShieldCheck, title: "VERIFIED DEALS", desc: "Every link is checked for authenticity by CheapShark network." },
           { icon: Info, title: "DATA SCAN", desc: "Prices reflect the last market scan (updated every 60 minutes)." },
           { icon: Heart, title: "TRACKING ENGINE", desc: "Instant notifications when prices drop below your custom thresholds." }
         ].map((item, i) => (
           <div key={i} className="p-8 bg-white/[0.02] border border-white/5 rounded-[2rem] space-y-4">
              <item.icon className="text-orange-500" size={32} />
              <h4 className="font-black tracking-widest text-sm italic">{item.title}</h4>
              <p className="text-gray-500 text-xs leading-relaxed uppercase">{item.desc}</p>
           </div>
         ))}
      </section>
    </div>
  );
}
