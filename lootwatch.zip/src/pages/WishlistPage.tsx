/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from 'react';
import { User } from 'firebase/auth';
import { db, signIn } from '../lib/firebase';
import { collection, onSnapshot, query, orderBy, doc, deleteDoc, updateDoc } from 'firebase/firestore';
import { UserWishlistItem } from '../types';
import { Heart, Trash2, ArrowRight, Wallet, ShoppingBag, Bell, AlertTriangle, Clock, Edit2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router-dom';

export default function WishlistPage({ user }: { user: User | null }) {
  const [items, setItems] = useState<UserWishlistItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [tempPrice, setTempPrice] = useState<string>("");
  const [lastScan, setLastScan] = useState<Date>(new Date());
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const notifiedIds = useRef<Set<string>>(new Set());

  // Request notification permission
  const requestNotificationPermission = async () => {
    if (!("Notification" in window)) return;
    const permission = await Notification.requestPermission();
    setNotificationsEnabled(permission === 'granted');
  };

  useEffect(() => {
    if ("Notification" in window) {
      setNotificationsEnabled(Notification.permission === 'granted');
    }
  }, []);

  // Monitor wishlist items for price drops
  useEffect(() => {
    if (!notificationsEnabled) return;

    items.forEach(item => {
      if (item.targetPrice && item.currentBestPrice && item.currentBestPrice <= item.targetPrice) {
        // Only notify if we haven't notified about this specific price hit in this session
        const notificationKey = `${item.gameId}-${item.currentBestPrice}`;
        if (!notifiedIds.current.has(notificationKey)) {
          new Notification("🎯 TARGET PRICE HIT!", {
            body: `${item.title} is now $${item.currentBestPrice}. Your target was $${item.targetPrice}!`,
            icon: item.thumb
          });
          notifiedIds.current.add(notificationKey);
        }
      }
    });
  }, [items, notificationsEnabled]);

  useEffect(() => {
    const scan = async () => {
      if (!user || items.length === 0) return;
      
      const updatedItems = await Promise.all(items.map(async (item) => {
        try {
          const game = await cheapSharkService.getGameById(item.gameId);
          const cheapestDeal = game.deals.reduce((prev, curr) => 
            parseFloat(curr.price) < parseFloat(prev.price) ? curr : prev
          );
          const newPrice = parseFloat(cheapestDeal.price);
          
          if (newPrice !== item.currentBestPrice) {
            await updateDoc(doc(db, 'users', user.uid, 'wishlist', item.gameId), {
              currentBestPrice: newPrice
            });
          }
          return { ...item, currentBestPrice: newPrice };
        } catch (e) {
          return item;
        }
      }));
      
      setLastScan(new Date());
    };

    const interval = setInterval(scan, 60000); // Scan every minute
    return () => clearInterval(interval);
  }, [user, items]);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    const q = query(
      collection(db, 'users', user.uid, 'wishlist'),
      orderBy('addedAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const wishlistItems: UserWishlistItem[] = [];
      snapshot.forEach((doc) => {
        wishlistItems.push(doc.data() as UserWishlistItem);
      });
      setItems(wishlistItems);
      setLoading(false);
    }, (error) => {
      console.error("Wishlist fetch error:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  const removeItem = async (gameId: string) => {
    if (!user) return;
    try {
      await deleteDoc(doc(db, 'users', user.uid, 'wishlist', gameId));
    } catch (e) {
      console.error("Delete error:", e);
    }
  };

  const updateTargetPrice = async (gameId: string) => {
    if (!user) return;
    const price = parseFloat(tempPrice);
    if (isNaN(price)) return;
    
    try {
      await updateDoc(doc(db, 'users', user.uid, 'wishlist', gameId), {
        targetPrice: price
      });
      setEditingId(null);
    } catch (e) {
      console.error("Update error:", e);
    }
  };

  if (!user) {
    return (
      <div className="max-w-xl mx-auto py-20 text-center space-y-8">
         <div className="w-24 h-24 bg-orange-500/10 rounded-full flex items-center justify-center mx-auto border-4 border-orange-500/20">
            <ShoppingBag className="text-orange-500" size={40} />
         </div>
         <div className="space-y-4">
            <h1 className="text-4xl font-black italic tracking-tighter uppercase">Track Your Loot</h1>
            <p className="text-gray-400">Login to save games, track historical lows, and get notifications when your favorite titles go on sale.</p>
         </div>
         <button 
           onClick={signIn}
           className="w-full bg-orange-600 hover:bg-orange-700 text-white py-4 rounded-2xl font-black uppercase tracking-[3px] transition-all transform hover:scale-105"
         >
           ENCRYPTED LOGIN
         </button>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="py-20 flex justify-center">
        <div className="w-12 h-12 border-4 border-orange-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-12">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-white/5 pb-8">
         <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-orange-500 font-black text-[10px] tracking-[4px] uppercase bg-orange-500/10 px-3 py-1 rounded">SAFE HOUSE</span>
              <span className="text-[10px] font-bold text-gray-500 uppercase flex items-center gap-1">
                <Clock size={10} className="text-orange-500" />
                Live Scan: {lastScan.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
            <h1 className="text-5xl font-black italic tracking-tighter uppercase leading-none">PERSONAL <span className="text-orange-500">VAULT</span></h1>
         </div>
         <div className="flex gap-4">
            {!notificationsEnabled && "Notification" in window && (
               <button 
                 onClick={requestNotificationPermission}
                 className="px-4 py-2 bg-orange-500/10 border border-orange-500/30 text-orange-500 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-orange-500 hover:text-white transition-all shadow-[0_0_20px_rgba(249,115,22,0.1)] flex items-center gap-2"
               >
                 <Bell size={12} />
                 Enable Alerts
               </button>
            )}
            <div className="px-6 py-3 bg-white/5 border border-white/10 rounded-2xl flex items-center gap-3">
               <Wallet className="text-gray-500" size={20} />
               <div className="flex flex-col leading-none">
                  <span className="text-[10px] text-gray-500 font-bold uppercase mb-1">Items Tracked</span>
                  <span className="text-lg font-black italic">{items.length}</span>
               </div>
            </div>
            <div className="px-6 py-3 bg-orange-500/10 border border-orange-500/20 rounded-2xl flex items-center gap-3">
               <Bell className="text-orange-500" size={20} />
               <div className="flex flex-col leading-none">
                  <span className="text-[10px] text-orange-500 font-bold uppercase mb-1">Active Alerts</span>
                  <span className="text-lg font-black italic text-orange-500">{items.length}</span>
               </div>
            </div>
         </div>
      </header>

      {items.length === 0 ? (
        <div className="py-32 text-center space-y-6 bg-white/[0.01] rounded-[3rem] border border-dashed border-white/10">
           <Heart className="mx-auto text-white/10" size={80} />
           <div className="space-y-2">
              <h2 className="text-2xl font-black italic uppercase tracking-widest text-gray-400">Vault is Empty</h2>
              <p className="text-gray-600 font-bold uppercase text-xs">No active scans detected in the database.</p>
           </div>
           <Link 
            to="/search" 
            className="inline-flex items-center gap-2 text-orange-500 font-black uppercase hover:gap-4 transition-all"
           >
             Initialize Scan
             <ArrowRight size={20} />
           </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          <AnimatePresence>
            {items.map((item) => (
              <motion.div
                layout
                key={item.gameId}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -100 }}
                className="group relative flex flex-col md:flex-row items-center gap-6 p-6 bg-[#111] border border-white/5 rounded-3xl hover:border-orange-500/30 transition-all"
              >
                 <div className="w-full md:w-48 h-28 rounded-2xl overflow-hidden bg-white/5 border border-white/10">
                    <img 
                      src={item.thumb} 
                      alt={item.title} 
                      className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500 scale-105 group-hover:scale-100" 
                      referrerPolicy="no-referrer"
                    />
                 </div>
                 
                 <div className="flex-1 text-center md:text-left space-y-1">
                    <h3 className="text-xl font-black uppercase italic tracking-tight">{item.title}</h3>
                    <div className="flex items-center justify-center md:justify-start gap-4 text-[10px] font-black uppercase tracking-widest text-gray-500">
                       <span className="flex items-center gap-1">
                         <Clock size={12} />
                         Added: {new Date(item.addedAt).toLocaleDateString()}
                       </span>
                    </div>
                 </div>

                 <div className="flex flex-col md:flex-row items-center gap-8 w-full md:w-auto">
                    <div className="flex flex-col items-center md:items-end w-32">
                       <span className="block text-[10px] font-black uppercase text-orange-500 tracking-widest">Target Price</span>
                       {editingId === item.gameId ? (
                         <div className="flex items-center gap-2">
                           <input 
                             autoFocus
                             className="w-20 bg-white/5 border border-orange-500/40 rounded px-2 py-1 text-sm font-bold text-white focus:outline-none"
                             value={tempPrice}
                             onChange={(e) => setTempPrice(e.target.value)}
                             onBlur={() => updateTargetPrice(item.gameId)}
                             onKeyDown={(e) => e.key === 'Enter' && updateTargetPrice(item.gameId)}
                           />
                         </div>
                       ) : (
                         <button 
                           onClick={() => {
                             setEditingId(item.gameId);
                             setTempPrice(item.targetPrice?.toString() || "");
                           }}
                           className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
                         >
                           <div className="text-2xl font-black italic tracking-tighter">
                             ${item.targetPrice || '--'}
                           </div>
                           <Edit2 size={12} />
                         </button>
                       )}
                    </div>

                    <div className="text-center md:text-right w-32 border-l border-white/5 pl-4">
                       <span className="block text-[10px] font-black uppercase text-gray-500 tracking-widest">Market Status</span>
                       <div className={`text-2xl font-black italic ${item.targetPrice && item.currentBestPrice && item.currentBestPrice <= item.targetPrice ? 'text-green-500 scale-110 drop-shadow-[0_0_10px_rgba(34,197,94,0.3)]' : 'text-white'}`}>
                        ${item.currentBestPrice || '??'}
                       </div>
                    </div>
                    
                    <div className="flex gap-3 w-full md:w-auto">
                       <Link 
                        to={`/game/${item.gameId}`}
                        className="flex-1 md:flex-none px-6 py-4 bg-white text-black rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-orange-500 hover:text-white transition-all shadow-xl"
                       >
                         COMPARE
                       </Link>
                       <button 
                        onClick={() => removeItem(item.gameId)}
                        className="p-4 bg-white/5 border border-white/10 rounded-2xl text-gray-500 hover:bg-red-500/10 hover:text-red-500 hover:border-red-500/20 transition-all"
                       >
                          <Trash2 size={20} />
                       </button>
                    </div>
                 </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      {items.length > 0 && (
         <div className="p-8 bg-orange-500/5 rounded-3xl border border-dashed border-orange-500/20 flex flex-col md:flex-row items-center gap-6">
            <div className="w-12 h-12 bg-orange-500/10 rounded-full flex items-center justify-center shrink-0">
               <AlertTriangle size={24} className="text-orange-500" />
            </div>
            <div className="flex-1 text-center md:text-left space-y-1">
               <h4 className="font-black uppercase italic tracking-widest">Notification Engine Protocol</h4>
               <p className="text-xs text-gray-500 uppercase leading-relaxed">
                  The system scans for price drops every 60 minutes. You will see a notification alert in the dashboard whenever a game reaches a new historical low.
               </p>
            </div>
         </div>
      )}
    </div>
  );
}
