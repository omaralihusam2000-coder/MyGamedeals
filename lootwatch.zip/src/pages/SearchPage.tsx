/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { cheapSharkService } from '../services/cheapShark';
import { Search as SearchIcon, ArrowRight, TrendingUp, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router-dom';

export default function SearchPage() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const timer = setTimeout(async () => {
      if (query.length < 2) {
        setResults([]);
        return;
      }
      setLoading(true);
      try {
        const data = await cheapSharkService.searchGames(query);
        // Only show games with active deal IDs
        setResults(data.filter(g => g.cheapestDealID));
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [query]);

  return (
    <div className="max-w-4xl mx-auto space-y-12 min-h-[60vh]">
      <section className="text-center space-y-4">
         <h1 className="text-5xl font-black tracking-tighter uppercase italic">
            Search <span className="text-orange-500 underline decoration-4 underline-offset-8">Universe</span>
         </h1>
         <p className="text-gray-400 font-medium">Find any game across Steam, Epic, GOG, and more.</p>
      </section>

      <div className="relative group">
        <div className="absolute -inset-0.5 bg-gradient-to-r from-orange-500 to-red-600 rounded-2xl blur opacity-20 group-focus-within:opacity-50 transition duration-1000"></div>
        <div className="relative flex items-center bg-black rounded-2xl border border-white/10 p-2">
          <SearchIcon className="ml-4 text-gray-500" size={24} />
          <input
            autoFocus
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search for titles (e.g. 'Elden Ring', 'Cyberpunk')"
            className="w-full bg-transparent border-none focus:ring-0 text-white placeholder-gray-600 text-xl font-bold p-4"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <AnimatePresence mode="popLayout">
          {loading ? (
             Array.from({ length: 6 }).map((_, i) => (
              <div key={`skeleton-${i}`} className="border border-white/5 bg-[#111] rounded-xl p-4 flex items-center gap-4 animate-pulse">
                <div className="w-20 h-20 rounded-lg bg-white/5 flex-shrink-0" />
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-white/5 rounded w-3/4" />
                  <div className="h-3 bg-white/5 rounded w-1/2" />
                </div>
              </div>
             ))
          ) : results.map((game, index) => (
            <motion.div
              layout
              key={game.gameID}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ delay: index * 0.05 }}
              className="group border border-white/5 bg-[#111] hover:bg-white/5 rounded-xl p-4 flex items-center gap-4 transition-all hover:border-orange-500/40"
            >
              <div className="w-20 h-20 rounded-lg overflow-hidden bg-white/5 flex-shrink-0">
                <img 
                  src={game.thumb} 
                  alt={game.external} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-bold text-lg text-white truncate">{game.external}</h3>
                <div className="flex items-center gap-2 mt-1">
                   <span className="text-[10px] font-black uppercase text-gray-400 bg-white/5 px-2 py-0.5 rounded">ID: {game.gameID}</span>
                   <span className="text-orange-500 font-black text-sm">FROM ${game.cheapest}</span>
                </div>
              </div>
              <Link 
                to={`/game/${game.gameID}`}
                className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center text-gray-500 group-hover:bg-orange-500 group-hover:text-white group-hover:border-orange-500 transition-all"
              >
                <ArrowRight size={20} />
              </Link>
            </motion.div>
          ))}
        </AnimatePresence>

        {query.length >= 2 && results.length === 0 && !loading && (
           <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="col-span-full py-20 text-center text-gray-500 space-y-4"
           >
              <Info className="mx-auto text-orange-500 opacity-20" size={64} />
              <p className="text-xl font-bold uppercase tracking-widest italic">No Loot Found in this Sector</p>
           </motion.div>
        )}

        {query.length < 2 && (
          <div className="col-span-full border border-dashed border-white/10 rounded-3xl p-12 text-center text-gray-600 bg-white/[0.01]">
             <TrendingUp className="mx-auto mb-4 opacity-10" size={48} />
             <p className="font-bold uppercase tracking-widest text-sm">Start typing to scan the markets</p>
          </div>
        )}
      </div>
    </div>
  );
}
