/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

const BASE_URL = 'https://www.cheapshark.com/api/1.0';

export interface Deal {
  internalName: string;
  title: string;
  metacriticLink: string;
  dealID: string;
  storeID: string;
  gameID: string;
  salePrice: string;
  normalPrice: string;
  isOnSale: string;
  savings: string;
  metacriticScore: string;
  steamRatingText: string;
  steamRatingPercent: string;
  steamRatingCount: string;
  steamAppID: string;
  releaseDate: number;
  lastChange: number;
  dealRating: string;
  thumb: string;
}

export interface GameLookup {
  info: {
    title: string;
    steamAppID: string;
    thumb: string;
  };
  cheapestPriceEver: {
    price: string;
    date: number;
  };
  deals: {
    storeID: string;
    dealID: string;
    price: string;
    retailPrice: string;
    savings: string;
  }[];
}

export interface Store {
  storeID: string;
  storeName: string;
  isActive: number;
  images: {
    banner: string;
    logo: string;
    icon: string;
  };
}

export const cheapSharkService = {
  async getDeals(params: Record<string, string> = {}) {
    // Default to top deals
    const query = new URLSearchParams({
      pageSize: '30',
      ...params
    }).toString();
    const response = await fetch(`${BASE_URL}/deals?${query}`);
    return (await response.json()) as Deal[];
  },

  async getGameDeals(gameID: string) {
    const response = await fetch(`${BASE_URL}/games?id=${gameID}`);
    return (await response.json()) as GameLookup;
  },

  async searchGames(title: string) {
    const response = await fetch(`${BASE_URL}/games?title=${title}&limit=20`);
    return (await response.json()) as {
      gameID: string;
      steamAppID: string;
      cheapest: string;
      cheapestDealID: string;
      external: string;
      internal: string;
      thumb: string;
    }[];
  },

  async getStores() {
    const response = await fetch(`${BASE_URL}/stores`);
    return (await response.json()) as Store[];
  }
};
